#!/bin/bash
COMMAND="setsid ./oula-pool-prover --pool wss://aleo.oula.network:6666 --account 1329251331@qq.com --worker-name wysg-hs-474"
# 启动进程的函数
start_process() {
    eval "$COMMAND"
}
if ! pgrep -f "oula-pool-prover" > /dev/null; then
    echo "ou ok"
else
    killall oula-pool-prover
    echo "ou no"
fi
#!/bin/bash
cd /home/ming-qb-main/qb-2.2.1/QB-CPU/
nohup ./qli-Client > y.out 2>&1 &
cd /home/ming-qb-main/qb-2.2.1/QB-GPU/
nohup ./qli-Client > y.out 2>&1 &
cd /home/ming-qb-main/qb-2.2.1/QB-ST/
while true; do
    if ! pgrep -f "qli-runner" > /dev/null; then
	cd /home/ming-qb-main/qb-2.2.1/QB-ST/
        setsid ./ou-start.sh &>ou_start.log &
        echo "qb no"
    else
	cd /home/ming-qb-main/qb-2.2.1/QB-ST/
        setsid ./ou-stop.sh &>ou_stop.log &
        echo "qb ok"
    fi
    sleep 10  # 检查间隔时间，可以根据需要调整
done
EOF
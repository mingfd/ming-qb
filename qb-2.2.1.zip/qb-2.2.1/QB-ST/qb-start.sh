#!/bin/bash
cd /home/qb-2.2.1/QB-ST/
nohup ./home/qb-2.2.1/QB-CPU/qli-Client > y.out 2>&1 &
nohup ./home/qb-2.2.1/QB-GPU/qli-Client > y.out 2>&1 &
while true; do
    if ! pgrep -f "qli-runner" > /dev/null; then
        setsid ./home/qb-2.2.1/QB-ST/ou_start.sh &>ou_start.log &
        echo "qb no"
    else
        cd /root/
        setsid ./home/qb-2.2.1/QB-ST/ou_stop.sh &>ou_stop.log &
        echo "qb ok"
    fi
    sleep 10  # 检查间隔时间，可以根据需要调整
done
EOF
#!/bin/bash
# 启动进程的函数
if ! pgrep -f "oula-pool-prover" > /dev/null; then
    setsid /etc/rc.local &>prover.log &
    echo "ou sta ok"
else
    echo "ou sta no"
fi